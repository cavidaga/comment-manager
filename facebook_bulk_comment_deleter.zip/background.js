chrome.runtime.onInstalled.addListener(() => {
    console.log('Facebook Comment Management Extension installed.');
  });
  
  // Example: Listen for messages and send a response
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'deleteCheckedComments') {
      // You can handle the request here
      console.log('Request to delete checked comments received.');
    }
  });
  