(function runMacro() {
  // Function to delete selected comments
  function deleteCheckedComments() {
    const checkboxes = document.querySelectorAll('.comment-checkbox:checked'); // All checked boxes

    if (checkboxes.length === 0) {
      alert("No comments selected for deletion.");
      return;
    }

    let delay = 2000; // Delay between actions
    let index = 0;

    function processNext() {
      if (index >= checkboxes.length) {
        alert("Macro complete: Selected comments have been deleted.");
        return;
      }

      const checkbox = checkboxes[index];
      const commentContainer = checkbox.closest('div[role="article"]');
      const actionButton = commentContainer?.querySelector('div[aria-haspopup="menu"]');

      if (actionButton) {
        actionButton.click(); // Open the action menu

        setTimeout(() => {
          // Find and click the "Delete" option
          const deleteOption = Array.from(document.querySelectorAll('span'))
            .find(el => el.textContent.trim() === 'Delete');

          if (deleteOption) {
            deleteOption.click();

            setTimeout(() => {
              const confirmButton = document.querySelector('div[aria-label="Delete"]');
              if (confirmButton) confirmButton.click();
              index++;
              setTimeout(processNext, delay);
            }, delay / 2);
          }
        }, delay);
      } else {
        index++;
        setTimeout(processNext, delay);
      }
    }

    processNext();
  }

  // Function to hide selected comments
  function hideCheckedComments() {
    const checkboxes = document.querySelectorAll('.comment-checkbox:checked');

    if (checkboxes.length === 0) {
      alert("No comments selected for hiding.");
      return;
    }

    let delay = 2000;
    let index = 0;

    function processNext() {
      if (index >= checkboxes.length) {
        alert("Macro complete: Selected comments have been hidden.");
        return;
      }

      const checkbox = checkboxes[index];
      const commentContainer = checkbox.closest('div[role="article"]');
      const actionButton = commentContainer?.querySelector('div[aria-haspopup="menu"]');

      if (actionButton) {
        actionButton.click(); // Open the action menu

        setTimeout(() => {
          // Find and click the "Hide" option
          const hideOption = Array.from(document.querySelectorAll('span'))
            .find(el => el.textContent.trim() === 'Hide comment');

          if (hideOption) {
            hideOption.click();
            index++;
            setTimeout(processNext, delay);
          }
        }, delay);
      } else {
        index++;
        setTimeout(processNext, delay);
      }
    }

    processNext();
  }

  // Function to block selected users
  function blockCheckedUsers() {
    const checkboxes = document.querySelectorAll('.comment-checkbox:checked');

    if (checkboxes.length === 0) {
      alert("No comments selected for blocking.");
      return;
    }

    let delay = 2000;
    let index = 0;

    function processNext() {
      if (index >= checkboxes.length) {
        alert("Macro complete: Selected users have been blocked.");
        return;
      }

      const checkbox = checkboxes[index];
      const commentContainer = checkbox.closest('div[role="article"]');
      const actionButton = commentContainer?.querySelector('div[aria-haspopup="menu"]');

      if (actionButton) {
        actionButton.click(); // Open the action menu

        setTimeout(() => {
          // Find and click the "Block" option
          const blockOption = Array.from(document.querySelectorAll('span'))
            .find(el => el.textContent.trim() === 'Block');

          if (blockOption) {
            blockOption.click();

            setTimeout(() => {
              const confirmButton = document.querySelector('div[aria-label="Confirm"]');
              if (confirmButton) confirmButton.click();
              index++;
              setTimeout(processNext, delay);
            }, delay / 2);
          }
        }, delay);
      } else {
        index++;
        setTimeout(processNext, delay);
      }
    }

    processNext();
  }

  // Function to insert checkboxes
  function insertCheckboxes() {
    const commentContainers = document.querySelectorAll('div[aria-haspopup="menu"]');

    commentContainers.forEach((menuButton, index) => {
      const commentWrapper = menuButton.closest('div[role="article"]');
      if (!commentWrapper || commentWrapper.querySelector('.comment-checkbox')) return;

      // Create a checkbox
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.className = 'comment-checkbox';
      checkbox.dataset.commentIndex = index;
      checkbox.style.cssText = 'margin-right: 10px; cursor: pointer;';

      // Insert checkbox before the comment content
      commentWrapper.prepend(checkbox);
    });

    addRunButtons();
  }

  // Create buttons with icons for each action (delete, hide, block)
  function createIconButton(iconPath, action) {
    const button = document.createElement('button');
    const icon = document.createElement('img');
    icon.src = chrome.runtime.getURL(iconPath); // Use the correct URL for the icon
    icon.alt = action;
    icon.style.width = '30px';  // Size of the icon
    icon.style.height = '30px';
    icon.style.display = 'block'; // Ensure the image is displayed properly
    icon.style.margin = '0 auto'; // Center the icon within the button
    
    button.appendChild(icon);

    // Add event listener to the button for the action
    button.addEventListener('click', () => {
      if (action === 'deleteCheckedComments') {
        deleteCheckedComments();
      } else if (action === 'hideCheckedComments') {
        hideCheckedComments();
      } else if (action === 'blockCheckedUsers') {
        blockCheckedUsers();
      }
    });

    return button;
  }

  // Add buttons to the page
  function addRunButtons() {
    if (document.querySelector('#run-macro-btn')) return;

    // Delete button with icon
    const deleteButton = document.createElement('button');
    deleteButton.id = 'run-macro-btn';
    const deleteIcon = document.createElement('img');
    deleteIcon.src = chrome.runtime.getURL('icons/delete.png');  // Use the correct icon path
    deleteIcon.alt = 'Delete';
    deleteIcon.style.width = '30px';
    deleteIcon.style.height = '30px';
    deleteButton.appendChild(deleteIcon);
    deleteButton.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 20px;
      padding: 10px;
      background: red;
      color: white;
      border: none;
      cursor: pointer;
      z-index: 9999;
      display: flex;
      justify-content: center; /* Center icon within button */
      align-items: center; /* Center icon vertically */
      width: 50px; /* Adjust button width to fit icon */
      height: 50px; /* Adjust button height */
    `;
    document.body.appendChild(deleteButton);
    deleteButton.addEventListener('click', deleteCheckedComments);

    // Hide button with icon
    const hideButton = document.createElement('button');
    hideButton.id = 'run-hide-macro-btn';
    const hideIcon = document.createElement('img');
    hideIcon.src = chrome.runtime.getURL('icons/hide.png');  // Use the correct icon path
    hideIcon.alt = 'Hide';
    hideIcon.style.width = '30px';
    hideIcon.style.height = '30px';
    hideButton.appendChild(hideIcon);
    hideButton.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 160px;
      padding: 10px;
      background: green;
      color: white;
      border: none;
      cursor: pointer;
      z-index: 9999;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 50px;
      height: 50px;
    `;
    document.body.appendChild(hideButton);
    hideButton.addEventListener('click', hideCheckedComments);

    // Block button with icon
    const blockButton = document.createElement('button');
    blockButton.id = 'run-block-macro-btn';
    const blockIcon = document.createElement('img');
    blockIcon.src = chrome.runtime.getURL('icons/block.png');  // Use the correct icon path
    blockIcon.alt = 'Block';
    blockIcon.style.width = '30px';
    blockIcon.style.height = '30px';
    blockButton.appendChild(blockIcon);
    blockButton.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 300px;
      padding: 10px;
      background: blue;
      color: white;
      border: none;
      cursor: pointer;
      z-index: 9999;
      display: flex;
      justify-content: center;
      align-items: center;
      width: 50px;
      height: 50px;
    `;
    document.body.appendChild(blockButton);
    blockButton.addEventListener('click', blockCheckedUsers);
  }

  insertCheckboxes();
  const observer = new MutationObserver(insertCheckboxes);
  observer.observe(document.body, { childList: true, subtree: true });
})();
